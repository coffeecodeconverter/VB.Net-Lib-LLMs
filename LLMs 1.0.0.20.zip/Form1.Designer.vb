﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        TextBox_UserInput = New TextBox()
        Panel2 = New Panel()
        TextBox_AIResponse = New TextBox()
        Button_User_Submit = New Button()
        Button_AI_Clear = New Button()
        Panel3 = New Panel()
        ProgressBar_StatusBar = New ProgressBar()
        Panel4 = New Panel()
        TextBox_SystemPrompt = New TextBox()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Panel5 = New Panel()
        TextBox_Endpoint = New TextBox()
        Label4 = New Label()
        Panel6 = New Panel()
        TextBox_APIKey = New TextBox()
        Label5 = New Label()
        Panel7 = New Panel()
        RadioButtonOllama = New RadioButton()
        RadioButton_LMStudio = New RadioButton()
        RadioButton_OpenAI = New RadioButton()
        CheckBox_Stream = New CheckBox()
        Button_Abort = New Button()
        ComboBox_LLMModels = New ComboBox()
        Label6 = New Label()
        MenuStrip_Main = New MenuStrip()
        FileToolStripMenuItem = New ToolStripMenuItem()
        ExitToolStripMenuItem = New ToolStripMenuItem()
        EditToolStripMenuItem = New ToolStripMenuItem()
        ResetToolStripMenuItem = New ToolStripMenuItem()
        HelpToolStripMenuItem = New ToolStripMenuItem()
        AboutToolStripMenuItem = New ToolStripMenuItem()
        Panel8 = New Panel()
        TextBox_Temperature = New TextBox()
        Label7 = New Label()
        Panel9 = New Panel()
        TextBox_TopP = New TextBox()
        Label8 = New Label()
        Panel10 = New Panel()
        TextBox_MaxTokens = New TextBox()
        Label9 = New Label()
        CheckBox_AppendAIResponses = New CheckBox()
        CheckBox_AppendSystemPrompt = New CheckBox()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        Panel3.SuspendLayout()
        Panel4.SuspendLayout()
        Panel5.SuspendLayout()
        Panel6.SuspendLayout()
        Panel7.SuspendLayout()
        MenuStrip_Main.SuspendLayout()
        Panel8.SuspendLayout()
        Panel9.SuspendLayout()
        Panel10.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        Panel1.BorderStyle = BorderStyle.FixedSingle
        Panel1.Controls.Add(TextBox_UserInput)
        Panel1.Location = New Point(10, 146)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(817, 99)
        Panel1.TabIndex = 9
        ' 
        ' TextBox_UserInput
        ' 
        TextBox_UserInput.BorderStyle = BorderStyle.None
        TextBox_UserInput.Dock = DockStyle.Fill
        TextBox_UserInput.Location = New Point(0, 0)
        TextBox_UserInput.Multiline = True
        TextBox_UserInput.Name = "TextBox_UserInput"
        TextBox_UserInput.ScrollBars = ScrollBars.Vertical
        TextBox_UserInput.Size = New Size(815, 97)
        TextBox_UserInput.TabIndex = 0
        ' 
        ' Panel2
        ' 
        Panel2.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Panel2.BorderStyle = BorderStyle.FixedSingle
        Panel2.Controls.Add(TextBox_AIResponse)
        Panel2.Location = New Point(11, 422)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(816, 128)
        Panel2.TabIndex = 15
        ' 
        ' TextBox_AIResponse
        ' 
        TextBox_AIResponse.BackColor = Color.White
        TextBox_AIResponse.BorderStyle = BorderStyle.None
        TextBox_AIResponse.Dock = DockStyle.Fill
        TextBox_AIResponse.Location = New Point(0, 0)
        TextBox_AIResponse.Multiline = True
        TextBox_AIResponse.Name = "TextBox_AIResponse"
        TextBox_AIResponse.ReadOnly = True
        TextBox_AIResponse.ScrollBars = ScrollBars.Vertical
        TextBox_AIResponse.Size = New Size(814, 126)
        TextBox_AIResponse.TabIndex = 0
        ' 
        ' Button_User_Submit
        ' 
        Button_User_Submit.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        Button_User_Submit.Location = New Point(752, 252)
        Button_User_Submit.Name = "Button_User_Submit"
        Button_User_Submit.Size = New Size(75, 23)
        Button_User_Submit.TabIndex = 11
        Button_User_Submit.Text = "Submit"
        Button_User_Submit.UseVisualStyleBackColor = True
        ' 
        ' Button_AI_Clear
        ' 
        Button_AI_Clear.Anchor = AnchorStyles.Bottom Or AnchorStyles.Right
        Button_AI_Clear.Location = New Point(751, 556)
        Button_AI_Clear.Name = "Button_AI_Clear"
        Button_AI_Clear.Size = New Size(75, 23)
        Button_AI_Clear.TabIndex = 17
        Button_AI_Clear.Text = "Clear"
        Button_AI_Clear.UseVisualStyleBackColor = True
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.Silver
        Panel3.Controls.Add(ProgressBar_StatusBar)
        Panel3.Dock = DockStyle.Bottom
        Panel3.Location = New Point(0, 585)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(839, 51)
        Panel3.TabIndex = 20
        ' 
        ' ProgressBar_StatusBar
        ' 
        ProgressBar_StatusBar.Location = New Point(12, 22)
        ProgressBar_StatusBar.Name = "ProgressBar_StatusBar"
        ProgressBar_StatusBar.Size = New Size(72, 10)
        ProgressBar_StatusBar.TabIndex = 2
        ' 
        ' Panel4
        ' 
        Panel4.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        Panel4.BorderStyle = BorderStyle.FixedSingle
        Panel4.Controls.Add(TextBox_SystemPrompt)
        Panel4.Location = New Point(11, 283)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(816, 103)
        Panel4.TabIndex = 12
        ' 
        ' TextBox_SystemPrompt
        ' 
        TextBox_SystemPrompt.BorderStyle = BorderStyle.None
        TextBox_SystemPrompt.Dock = DockStyle.Fill
        TextBox_SystemPrompt.Location = New Point(0, 0)
        TextBox_SystemPrompt.Multiline = True
        TextBox_SystemPrompt.Name = "TextBox_SystemPrompt"
        TextBox_SystemPrompt.ScrollBars = ScrollBars.Vertical
        TextBox_SystemPrompt.Size = New Size(814, 101)
        TextBox_SystemPrompt.TabIndex = 0
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(12, 265)
        Label1.Name = "Label1"
        Label1.Size = New Size(286, 15)
        Label1.TabIndex = 12
        Label1.Text = "System Prompt (optional - leave blank if not needed)"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(11, 128)
        Label2.Name = "Label2"
        Label2.Size = New Size(73, 15)
        Label2.TabIndex = 9
        Label2.Text = "User Prompt"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(12, 404)
        Label3.Name = "Label3"
        Label3.Size = New Size(71, 15)
        Label3.TabIndex = 15
        Label3.Text = "AI Response"
        ' 
        ' Panel5
        ' 
        Panel5.Controls.Add(TextBox_Endpoint)
        Panel5.Controls.Add(Label4)
        Panel5.Location = New Point(12, 34)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(650, 24)
        Panel5.TabIndex = 2
        ' 
        ' TextBox_Endpoint
        ' 
        TextBox_Endpoint.AcceptsReturn = True
        TextBox_Endpoint.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        TextBox_Endpoint.BorderStyle = BorderStyle.FixedSingle
        TextBox_Endpoint.Location = New Point(58, 0)
        TextBox_Endpoint.Name = "TextBox_Endpoint"
        TextBox_Endpoint.Size = New Size(589, 23)
        TextBox_Endpoint.TabIndex = 2
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(3, 4)
        Label4.Name = "Label4"
        Label4.Size = New Size(55, 15)
        Label4.TabIndex = 0
        Label4.Text = "Endpoint"
        ' 
        ' Panel6
        ' 
        Panel6.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        Panel6.Controls.Add(TextBox_APIKey)
        Panel6.Controls.Add(Label5)
        Panel6.Location = New Point(668, 34)
        Panel6.Name = "Panel6"
        Panel6.Size = New Size(159, 24)
        Panel6.TabIndex = 3
        ' 
        ' TextBox_APIKey
        ' 
        TextBox_APIKey.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        TextBox_APIKey.BorderStyle = BorderStyle.FixedSingle
        TextBox_APIKey.Location = New Point(50, 0)
        TextBox_APIKey.Name = "TextBox_APIKey"
        TextBox_APIKey.Size = New Size(106, 23)
        TextBox_APIKey.TabIndex = 1
        TextBox_APIKey.Text = "APIKeyHere"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(3, 4)
        Label5.Name = "Label5"
        Label5.Size = New Size(47, 15)
        Label5.TabIndex = 0
        Label5.Text = "API Key"
        ' 
        ' Panel7
        ' 
        Panel7.Controls.Add(RadioButtonOllama)
        Panel7.Controls.Add(RadioButton_LMStudio)
        Panel7.Controls.Add(RadioButton_OpenAI)
        Panel7.Location = New Point(15, 64)
        Panel7.Name = "Panel7"
        Panel7.Size = New Size(220, 22)
        Panel7.TabIndex = 4
        ' 
        ' RadioButtonOllama
        ' 
        RadioButtonOllama.AutoSize = True
        RadioButtonOllama.Location = New Point(156, 2)
        RadioButtonOllama.Name = "RadioButtonOllama"
        RadioButtonOllama.Size = New Size(63, 19)
        RadioButtonOllama.TabIndex = 2
        RadioButtonOllama.TabStop = True
        RadioButtonOllama.Text = "Ollama"
        RadioButtonOllama.UseVisualStyleBackColor = True
        ' 
        ' RadioButton_LMStudio
        ' 
        RadioButton_LMStudio.AutoSize = True
        RadioButton_LMStudio.Location = New Point(74, 2)
        RadioButton_LMStudio.Name = "RadioButton_LMStudio"
        RadioButton_LMStudio.Size = New Size(76, 19)
        RadioButton_LMStudio.TabIndex = 1
        RadioButton_LMStudio.TabStop = True
        RadioButton_LMStudio.Text = "LMStudio"
        RadioButton_LMStudio.UseVisualStyleBackColor = True
        ' 
        ' RadioButton_OpenAI
        ' 
        RadioButton_OpenAI.AutoSize = True
        RadioButton_OpenAI.Location = New Point(3, 2)
        RadioButton_OpenAI.Name = "RadioButton_OpenAI"
        RadioButton_OpenAI.Size = New Size(65, 19)
        RadioButton_OpenAI.TabIndex = 0
        RadioButton_OpenAI.TabStop = True
        RadioButton_OpenAI.Text = "OpenAI"
        RadioButton_OpenAI.UseVisualStyleBackColor = True
        ' 
        ' CheckBox_Stream
        ' 
        CheckBox_Stream.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        CheckBox_Stream.AutoSize = True
        CheckBox_Stream.Checked = True
        CheckBox_Stream.CheckState = CheckState.Checked
        CheckBox_Stream.Location = New Point(683, 255)
        CheckBox_Stream.Name = "CheckBox_Stream"
        CheckBox_Stream.Size = New Size(63, 19)
        CheckBox_Stream.TabIndex = 10
        CheckBox_Stream.Text = "Stream"
        CheckBox_Stream.UseVisualStyleBackColor = True
        ' 
        ' Button_Abort
        ' 
        Button_Abort.Anchor = AnchorStyles.Bottom Or AnchorStyles.Right
        Button_Abort.Location = New Point(671, 556)
        Button_Abort.Name = "Button_Abort"
        Button_Abort.Size = New Size(75, 23)
        Button_Abort.TabIndex = 16
        Button_Abort.Text = "Abort"
        Button_Abort.UseVisualStyleBackColor = True
        ' 
        ' ComboBox_LLMModels
        ' 
        ComboBox_LLMModels.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        ComboBox_LLMModels.DropDownStyle = ComboBoxStyle.DropDownList
        ComboBox_LLMModels.FormattingEnabled = True
        ComboBox_LLMModels.Items.AddRange(New Object() {"gpt-3.5-turbo", "llama3.2:1b"})
        ComboBox_LLMModels.Location = New Point(300, 63)
        ComboBox_LLMModels.Name = "ComboBox_LLMModels"
        ComboBox_LLMModels.Size = New Size(191, 23)
        ComboBox_LLMModels.Sorted = True
        ComboBox_LLMModels.TabIndex = 5
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(254, 68)
        Label6.Name = "Label6"
        Label6.Size = New Size(44, 15)
        Label6.TabIndex = 15
        Label6.Text = "Model:"
        ' 
        ' MenuStrip_Main
        ' 
        MenuStrip_Main.BackColor = Color.LightGray
        MenuStrip_Main.Items.AddRange(New ToolStripItem() {FileToolStripMenuItem, EditToolStripMenuItem, HelpToolStripMenuItem})
        MenuStrip_Main.Location = New Point(0, 0)
        MenuStrip_Main.Name = "MenuStrip_Main"
        MenuStrip_Main.Size = New Size(839, 24)
        MenuStrip_Main.TabIndex = 1
        MenuStrip_Main.Text = "MenuStrip1"
        ' 
        ' FileToolStripMenuItem
        ' 
        FileToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {ExitToolStripMenuItem})
        FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        FileToolStripMenuItem.Size = New Size(37, 20)
        FileToolStripMenuItem.Text = "File"
        ' 
        ' ExitToolStripMenuItem
        ' 
        ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        ExitToolStripMenuItem.Size = New Size(93, 22)
        ExitToolStripMenuItem.Text = "Exit"
        ' 
        ' EditToolStripMenuItem
        ' 
        EditToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {ResetToolStripMenuItem})
        EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        EditToolStripMenuItem.Size = New Size(39, 20)
        EditToolStripMenuItem.Text = "Edit"
        ' 
        ' ResetToolStripMenuItem
        ' 
        ResetToolStripMenuItem.Name = "ResetToolStripMenuItem"
        ResetToolStripMenuItem.Size = New Size(150, 22)
        ResetToolStripMenuItem.Text = "Reset all Fields"
        ' 
        ' HelpToolStripMenuItem
        ' 
        HelpToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {AboutToolStripMenuItem})
        HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        HelpToolStripMenuItem.Size = New Size(44, 20)
        HelpToolStripMenuItem.Text = "Help"
        ' 
        ' AboutToolStripMenuItem
        ' 
        AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        AboutToolStripMenuItem.Size = New Size(107, 22)
        AboutToolStripMenuItem.Text = "About"
        ' 
        ' Panel8
        ' 
        Panel8.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        Panel8.Controls.Add(TextBox_Temperature)
        Panel8.Controls.Add(Label7)
        Panel8.Location = New Point(497, 62)
        Panel8.Name = "Panel8"
        Panel8.Size = New Size(110, 24)
        Panel8.TabIndex = 6
        ' 
        ' TextBox_Temperature
        ' 
        TextBox_Temperature.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        TextBox_Temperature.BorderStyle = BorderStyle.FixedSingle
        TextBox_Temperature.Font = New Font("Calibri", 8.25F, FontStyle.Regular, GraphicsUnit.Point)
        TextBox_Temperature.Location = New Point(79, 1)
        TextBox_Temperature.Name = "TextBox_Temperature"
        TextBox_Temperature.Size = New Size(28, 21)
        TextBox_Temperature.TabIndex = 1
        TextBox_Temperature.Text = "0.7"
        TextBox_Temperature.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(3, 4)
        Label7.Name = "Label7"
        Label7.Size = New Size(73, 15)
        Label7.TabIndex = 0
        Label7.Text = "Temperature"
        ' 
        ' Panel9
        ' 
        Panel9.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        Panel9.Controls.Add(TextBox_TopP)
        Panel9.Controls.Add(Label8)
        Panel9.Location = New Point(613, 62)
        Panel9.Name = "Panel9"
        Panel9.Size = New Size(74, 24)
        Panel9.TabIndex = 7
        ' 
        ' TextBox_TopP
        ' 
        TextBox_TopP.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        TextBox_TopP.BorderStyle = BorderStyle.FixedSingle
        TextBox_TopP.Font = New Font("Calibri", 8.25F, FontStyle.Regular, GraphicsUnit.Point)
        TextBox_TopP.Location = New Point(43, 1)
        TextBox_TopP.Name = "TextBox_TopP"
        TextBox_TopP.Size = New Size(28, 21)
        TextBox_TopP.TabIndex = 1
        TextBox_TopP.Text = "1.0"
        TextBox_TopP.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Location = New Point(3, 4)
        Label8.Name = "Label8"
        Label8.Size = New Size(33, 15)
        Label8.TabIndex = 0
        Label8.Text = "TopP"
        ' 
        ' Panel10
        ' 
        Panel10.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        Panel10.Controls.Add(TextBox_MaxTokens)
        Panel10.Controls.Add(Label9)
        Panel10.Location = New Point(693, 62)
        Panel10.Name = "Panel10"
        Panel10.Size = New Size(134, 24)
        Panel10.TabIndex = 8
        ' 
        ' TextBox_MaxTokens
        ' 
        TextBox_MaxTokens.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        TextBox_MaxTokens.BorderStyle = BorderStyle.FixedSingle
        TextBox_MaxTokens.Font = New Font("Calibri", 8.25F, FontStyle.Regular, GraphicsUnit.Point)
        TextBox_MaxTokens.Location = New Point(78, 1)
        TextBox_MaxTokens.Name = "TextBox_MaxTokens"
        TextBox_MaxTokens.Size = New Size(53, 21)
        TextBox_MaxTokens.TabIndex = 1
        TextBox_MaxTokens.Text = "1024"
        TextBox_MaxTokens.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Location = New Point(3, 4)
        Label9.Name = "Label9"
        Label9.Size = New Size(69, 15)
        Label9.TabIndex = 0
        Label9.Text = "Max Tokens"
        ' 
        ' CheckBox_AppendAIResponses
        ' 
        CheckBox_AppendAIResponses.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        CheckBox_AppendAIResponses.AutoSize = True
        CheckBox_AppendAIResponses.Location = New Point(599, 397)
        CheckBox_AppendAIResponses.Name = "CheckBox_AppendAIResponses"
        CheckBox_AppendAIResponses.Size = New Size(68, 19)
        CheckBox_AppendAIResponses.TabIndex = 13
        CheckBox_AppendAIResponses.Text = "Append"
        CheckBox_AppendAIResponses.UseVisualStyleBackColor = True
        ' 
        ' CheckBox_AppendSystemPrompt
        ' 
        CheckBox_AppendSystemPrompt.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        CheckBox_AppendSystemPrompt.AutoSize = True
        CheckBox_AppendSystemPrompt.Location = New Point(680, 397)
        CheckBox_AppendSystemPrompt.Name = "CheckBox_AppendSystemPrompt"
        CheckBox_AppendSystemPrompt.Size = New Size(152, 19)
        CheckBox_AppendSystemPrompt.TabIndex = 14
        CheckBox_AppendSystemPrompt.Text = "Append System Prompt"
        CheckBox_AppendSystemPrompt.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(839, 636)
        Controls.Add(CheckBox_AppendSystemPrompt)
        Controls.Add(CheckBox_AppendAIResponses)
        Controls.Add(Panel10)
        Controls.Add(Panel9)
        Controls.Add(Panel8)
        Controls.Add(Label6)
        Controls.Add(ComboBox_LLMModels)
        Controls.Add(Button_Abort)
        Controls.Add(CheckBox_Stream)
        Controls.Add(Panel7)
        Controls.Add(Panel6)
        Controls.Add(Panel5)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(Panel4)
        Controls.Add(Panel3)
        Controls.Add(Button_AI_Clear)
        Controls.Add(Button_User_Submit)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        Controls.Add(MenuStrip_Main)
        MainMenuStrip = MenuStrip_Main
        Name = "Form1"
        StartPosition = FormStartPosition.CenterScreen
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel3.ResumeLayout(False)
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        Panel5.ResumeLayout(False)
        Panel5.PerformLayout()
        Panel6.ResumeLayout(False)
        Panel6.PerformLayout()
        Panel7.ResumeLayout(False)
        Panel7.PerformLayout()
        MenuStrip_Main.ResumeLayout(False)
        MenuStrip_Main.PerformLayout()
        Panel8.ResumeLayout(False)
        Panel8.PerformLayout()
        Panel9.ResumeLayout(False)
        Panel9.PerformLayout()
        Panel10.ResumeLayout(False)
        Panel10.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents TextBox_UserInput As TextBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TextBox_AIResponse As TextBox
    Friend WithEvents Button_User_Submit As Button
    Friend WithEvents Button_AI_Clear As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents TextBox_SystemPrompt As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents TextBox_Endpoint As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents TextBox_APIKey As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Panel7 As Panel
    Friend WithEvents RadioButtonOllama As RadioButton
    Friend WithEvents RadioButton_LMStudio As RadioButton
    Friend WithEvents RadioButton_OpenAI As RadioButton
    Friend WithEvents CheckBox_Stream As CheckBox
    Friend WithEvents Button_Abort As Button
    Friend WithEvents ComboBox_LLMModels As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents MenuStrip_Main As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Panel8 As Panel
    Friend WithEvents TextBox_Temperature As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Panel9 As Panel
    Friend WithEvents TextBox_TopP As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Panel10 As Panel
    Friend WithEvents TextBox_MaxTokens As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents ProgressBar_StatusBar As ProgressBar
    Friend WithEvents CheckBox_AppendAIResponses As CheckBox
    Friend WithEvents EditToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ResetToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CheckBox_AppendSystemPrompt As CheckBox

End Class
