﻿


Imports System.ComponentModel
Imports System.Reflection

Public Class Form1


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FormAbout.Label_About_Version.Text = moduleVersionLLMs
        ResetUI()
    End Sub




    ' NOTE you need both the Button Code, AND write your OWN callback function to update a textbox, or label, or whatever you want PER PROJECT
    ' see the following 2 x Functions to demonstrate 

    Private Async Sub Button_User_Submit_Click(sender As Object, e As EventArgs) Handles Button_User_Submit.Click
        Try
            LoadingShow()
            Dim userInput As String = TextBox_UserInput.Text
            Dim systemPrompt As String = TextBox_SystemPrompt.Text
            Dim maxTokens As Integer = CInt(TextBox_MaxTokens.Text)
            Dim temperature As Double = CDbl(TextBox_Temperature.Text)
            Dim topP As Double = CDbl(TextBox_TopP.Text)
            Dim modelName As String = ComboBox_LLMModels.SelectedItem.ToString()
            Dim imageData As Byte() = Nothing
            Dim endpoint As String = TextBox_Endpoint.Text
            Dim apiKey As String = TextBox_APIKey.Text
            Dim streamResponse As Boolean = CheckBox_Stream.Checked

            If CheckBox_AppendAIResponses.Checked = True Then
                If CheckBox_AppendSystemPrompt.Checked = True Then
                    TextBox_AIResponse.AppendText("SYSTEM PROMPT: " & vbCrLf & systemPrompt & vbCrLf & vbCrLf & "USER: " & vbCrLf & userInput & vbCrLf & vbCrLf & "AI: " & vbCrLf)
                Else
                    TextBox_AIResponse.AppendText("USER: " & vbCrLf & userInput & vbCrLf & vbCrLf & "AI: " & vbCrLf)
                End If

            Else
                If CheckBox_AppendSystemPrompt.Checked = True Then
                    TextBox_AIResponse.Text = ""
                    TextBox_AIResponse.AppendText("SYSTEM PROMPT: " & vbCrLf & systemPrompt & vbCrLf & vbCrLf & "AI: " & vbCrLf)
                Else
                    TextBox_AIResponse.Text = ""
                End If
            End If

            ' Bare Minimum Example: your input and a callback to stream the response asynchronously
            'Await AskAI(TextBox_UserInput.Text, callBackFunc:=AddressOf UpdateTextBox)

            ' ALL Parameter Example:
            Await AskAI(userInput, systemPrompt, maxTokens, temperature, topP, modelName, imageData, endpoint, apiKey, streamResponse, AddressOf UpdateTextBox)

            LoadingHide()
        Catch ex As Exception
            MessageBox.Show("Error getting LLM response:" & vbCrLf & vbCrLf & ex.Message)
        End Try
    End Sub



    ' The callback method to update the TextBox
    ' but this is only relevant to THIS project, thus your callback must be bespoke PER PROJECT 
    Public Sub UpdateTextBox(text As String)
        ' Ensure UI updates are done on the UI thread
        If TextBox_AIResponse.InvokeRequired Then
            TextBox_AIResponse.Invoke(New Action(Of String)(AddressOf UpdateTextBox), text)
        Else
            TextBox_AIResponse.AppendText(text)
            TextBox_AIResponse.SelectionStart = TextBox_AIResponse.TextLength
            TextBox_AIResponse.ScrollToCaret()
        End If
    End Sub





    Private Sub RadioButton_OpenAI_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton_OpenAI.CheckedChanged
        SetEndpoint("https://api.openai.com/v1/completions")
    End Sub

    Private Sub RadioButton_LMStudio_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton_LMStudio.CheckedChanged
        SetEndpoint("http://127.0.0.1:1234/v1/chat/completions")
    End Sub

    Private Sub RadioButtonOllama_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButtonOllama.CheckedChanged
        SetEndpoint("http://127.0.0.1:11434/api/generate")
    End Sub

    Private Sub SetEndpoint(endpoint As String)
        TextBox_Endpoint.Text = endpoint
    End Sub




    Private Sub Button_Abort_Click(sender As Object, e As EventArgs) Handles Button_Abort.Click
        AbortAIRequest()
    End Sub

    Private Sub Button_AI_Clear_Click(sender As Object, e As EventArgs) Handles Button_AI_Clear.Click
        TextBox_AIResponse.Text = ""
    End Sub




    Private Sub LoadingShow()
        ProgressBar_StatusBar.Step = 0
        ProgressBar_StatusBar.Style = ProgressBarStyle.Marquee
    End Sub

    Private Sub LoadingHide()
        ProgressBar_StatusBar.Style = ProgressBarStyle.Blocks
        ProgressBar_StatusBar.Step = 0
    End Sub



    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        FormAbout.ShowDialog()
    End Sub

    Private Sub ResetToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ResetToolStripMenuItem.Click
        ResetUI()
    End Sub





    Private Sub ResetUI()
        RadioButton_LMStudio.Checked = True
        ComboBox_LLMModels.SelectedItem = "llama3.2:1b" ' just because ollama accepts it, and lmstudio ignores it, so works all round
        TextBox_APIKey.Text = "APIKeyHere"
        TextBox_Temperature.Text = 0.7
        TextBox_TopP.Text = 1.0
        TextBox_MaxTokens.Text = 1024
        TextBox_UserInput.Text = ""
        TextBox_SystemPrompt.Text = ""
        TextBox_AIResponse.Text = ""
        CheckBox_Stream.Checked = True
        CheckBox_AppendAIResponses.Checked = False
        CheckBox_AppendSystemPrompt.Checked = False
        LoadingHide()
    End Sub

    Private Sub TextBox_Temperature_TextChanged(sender As Object, e As EventArgs) Handles TextBox_Temperature.TextChanged

    End Sub

    Private Sub TextBox_TopP_TextChanged(sender As Object, e As EventArgs) Handles TextBox_TopP.TextChanged

    End Sub

    Private Sub TextBox_MaxTokens_TextChanged(sender As Object, e As EventArgs) Handles TextBox_MaxTokens.TextChanged

    End Sub


    Private Sub TextBox_TopP_Validating(sender As Object, e As CancelEventArgs) Handles TextBox_TopP.Validating
        ' Validate input to ensure it's a valid double
        If Not IsValidDouble(TextBox_TopP.Text) AndAlso TextBox_TopP.Text.Length > 0 Then
            ' Optionally, clear the textbox if invalid input is detected
            TextBox_TopP.Text = "1.0"
            MessageBox.Show("Please enter a valid number.")

        End If
    End Sub

    Private Sub TextBox_Temperature_Validating(sender As Object, e As CancelEventArgs) Handles TextBox_Temperature.Validating
        ' Validate input to ensure it's a valid double
        If Not IsValidDouble(TextBox_Temperature.Text) AndAlso TextBox_Temperature.Text.Length > 0 Then
            ' Optionally, clear the textbox if invalid input is detected
            TextBox_Temperature.Text = "0.7"
            MessageBox.Show("Please enter a valid number.")
        End If
    End Sub


    ' Helper function to check if the input is a valid double
    Private Function IsValidDouble(input As String) As Boolean
        Dim result As Double
        Return Double.TryParse(input, result)
    End Function

    Private Sub TextBox_MaxTokens_Validating(sender As Object, e As CancelEventArgs) Handles TextBox_MaxTokens.Validating
        ' Check if the input is a valid integer (0 to 9)
        If Not IsValidInteger(TextBox_MaxTokens.Text) Then
            ' If invalid, show a message and cancel the event
            MessageBox.Show("Please enter a valid integer (0-9) only.")
            TextBox_MaxTokens.Text = 1024
            e.Cancel = True ' This will prevent the focus from leaving the textbox
        End If
    End Sub

    ' Helper function to check if the input is a valid integer (0-9)
    Private Function IsValidInteger(input As String) As Boolean
        ' Check if the input consists only of digits and has a valid length (no spaces or special characters)
        Return input.All(AddressOf Char.IsDigit)
    End Function


End Class




