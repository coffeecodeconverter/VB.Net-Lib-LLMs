﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormAbout
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormAbout))
        Panel1 = New Panel()
        TextBox_CodeExamples = New TextBox()
        Panel2 = New Panel()
        TextBox_About = New TextBox()
        Button_About_CodeExampleMinimum = New Button()
        Button_About_CodeExampleFull = New Button()
        Button_About_Close = New Button()
        Label4 = New Label()
        Label_About_Version = New Label()
        Button_About_CodeExamplesBasic = New Button()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        Panel1.BorderStyle = BorderStyle.FixedSingle
        Panel1.Controls.Add(TextBox_CodeExamples)
        Panel1.Location = New Point(12, 147)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(695, 613)
        Panel1.TabIndex = 0
        ' 
        ' TextBox_CodeExamples
        ' 
        TextBox_CodeExamples.BackColor = Color.White
        TextBox_CodeExamples.BorderStyle = BorderStyle.None
        TextBox_CodeExamples.Dock = DockStyle.Fill
        TextBox_CodeExamples.Font = New Font("Consolas", 8.25F, FontStyle.Regular, GraphicsUnit.Point)
        TextBox_CodeExamples.Location = New Point(0, 0)
        TextBox_CodeExamples.Multiline = True
        TextBox_CodeExamples.Name = "TextBox_CodeExamples"
        TextBox_CodeExamples.ReadOnly = True
        TextBox_CodeExamples.ScrollBars = ScrollBars.Vertical
        TextBox_CodeExamples.Size = New Size(693, 611)
        TextBox_CodeExamples.TabIndex = 0
        ' 
        ' Panel2
        ' 
        Panel2.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        Panel2.Controls.Add(TextBox_About)
        Panel2.Location = New Point(11, 34)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(695, 56)
        Panel2.TabIndex = 1
        ' 
        ' TextBox_About
        ' 
        TextBox_About.BackColor = SystemColors.Control
        TextBox_About.BorderStyle = BorderStyle.None
        TextBox_About.Dock = DockStyle.Fill
        TextBox_About.Location = New Point(0, 0)
        TextBox_About.Multiline = True
        TextBox_About.Name = "TextBox_About"
        TextBox_About.Size = New Size(695, 56)
        TextBox_About.TabIndex = 0
        TextBox_About.Text = resources.GetString("TextBox_About.Text")
        ' 
        ' Button_About_CodeExampleMinimum
        ' 
        Button_About_CodeExampleMinimum.Location = New Point(14, 120)
        Button_About_CodeExampleMinimum.Name = "Button_About_CodeExampleMinimum"
        Button_About_CodeExampleMinimum.Size = New Size(75, 23)
        Button_About_CodeExampleMinimum.TabIndex = 2
        Button_About_CodeExampleMinimum.Text = "Minimum"
        Button_About_CodeExampleMinimum.UseVisualStyleBackColor = True
        ' 
        ' Button_About_CodeExampleFull
        ' 
        Button_About_CodeExampleFull.Location = New Point(176, 120)
        Button_About_CodeExampleFull.Name = "Button_About_CodeExampleFull"
        Button_About_CodeExampleFull.Size = New Size(75, 23)
        Button_About_CodeExampleFull.TabIndex = 3
        Button_About_CodeExampleFull.Text = "Full"
        Button_About_CodeExampleFull.UseVisualStyleBackColor = True
        ' 
        ' Button_About_Close
        ' 
        Button_About_Close.Anchor = AnchorStyles.Bottom Or AnchorStyles.Right
        Button_About_Close.Location = New Point(632, 774)
        Button_About_Close.Name = "Button_About_Close"
        Button_About_Close.Size = New Size(75, 23)
        Button_About_Close.TabIndex = 4
        Button_About_Close.Text = "Close"
        Button_About_Close.UseVisualStyleBackColor = True
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(14, 100)
        Label4.Name = "Label4"
        Label4.Size = New Size(91, 15)
        Label4.TabIndex = 5
        Label4.Text = "Code Examples:"
        ' 
        ' Label_About_Version
        ' 
        Label_About_Version.AutoSize = True
        Label_About_Version.Location = New Point(11, 9)
        Label_About_Version.Name = "Label_About_Version"
        Label_About_Version.Size = New Size(48, 15)
        Label_About_Version.TabIndex = 6
        Label_About_Version.Text = "Version "
        ' 
        ' Button_About_CodeExamplesBasic
        ' 
        Button_About_CodeExamplesBasic.Location = New Point(95, 120)
        Button_About_CodeExamplesBasic.Name = "Button_About_CodeExamplesBasic"
        Button_About_CodeExamplesBasic.Size = New Size(75, 23)
        Button_About_CodeExamplesBasic.TabIndex = 7
        Button_About_CodeExamplesBasic.Text = "Basic"
        Button_About_CodeExamplesBasic.UseVisualStyleBackColor = True
        ' 
        ' FormAbout
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(719, 811)
        Controls.Add(Button_About_CodeExamplesBasic)
        Controls.Add(Label_About_Version)
        Controls.Add(Label4)
        Controls.Add(Button_About_Close)
        Controls.Add(Button_About_CodeExampleFull)
        Controls.Add(Button_About_CodeExampleMinimum)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        MaximizeBox = False
        MinimizeBox = False
        Name = "FormAbout"
        ShowIcon = False
        StartPosition = FormStartPosition.CenterScreen
        Text = "About"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents TextBox_CodeExamples As TextBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TextBox_About As TextBox
    Friend WithEvents Button_About_CodeExampleMinimum As Button
    Friend WithEvents Button_About_CodeExampleFull As Button
    Friend WithEvents Button_About_Close As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Label_About_Version As Label
    Friend WithEvents Button_About_CodeExamplesBasic As Button
End Class
