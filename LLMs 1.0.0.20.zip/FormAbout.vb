﻿Public Class FormAbout



    Dim codeExample_BareMinimum As String = $"
Private Async Sub Button_User_Submit_Click(sender As Object, e As EventArgs) Handles Button_User_Submit.Click
        Await AskAI(TextBox_UserInput.Text, callBackFunc:=AddressOf CallBackFunction)
End Sub


Public Sub CallBackFunction(text As String)
    If TextBox_AIResponse.InvokeRequired Then
        TextBox_AIResponse.Invoke(New Action(Of String)(AddressOf CallBackFunction), text)
    Else
        TextBox_AIResponse.AppendText(text)
        TextBox_AIResponse.SelectionStart = TextBox_AIResponse.TextLength
        TextBox_AIResponse.ScrollToCaret()
    End If
End Sub
"



    Dim codeExample_Basic As String = $"
Private Async Sub Button_User_Submit_Click(sender As Object, e As EventArgs) Handles Button_User_Submit.Click
    Try
        Dim userInput As String = TextBox_UserInput.Text

        If CheckBox_AppendAIResponses.Checked = True Then
            TextBox_AIResponse.AppendText(""USER: "" & vbCrLf & userInput & vbCrLf & vbCrLf & ""AI: "" & vbCrLf)
        Else
            TextBox_AIResponse.Text = """"
        End If

        Await AskAI(TextBox_UserInput.Text, callBackFunc:=AddressOf CallBackFunction)
    Catch ex As Exception
        MessageBox.Show(""Error getting LLM response:"" & vbCrLf & vbCrLf & ex.Message)
    End Try
End Sub


Public Sub CallBackFunction(text As String)
    If TextBox_AIResponse.InvokeRequired Then
        TextBox_AIResponse.Invoke(New Action(Of String)(AddressOf CallBackFunction), text)
    Else
        TextBox_AIResponse.AppendText(text)
        TextBox_AIResponse.SelectionStart = TextBox_AIResponse.TextLength
        TextBox_AIResponse.ScrollToCaret()
    End If
End Sub


Private Sub Button_Abort_Click(sender As Object, e As EventArgs) Handles Button_Abort.Click
    AbortAIRequest()
End Sub
"



    Dim codeExample_AllParameters As String = $"
Private Async Sub Button_User_Submit_Click(sender As Object, e As EventArgs) Handles Button_User_Submit.Click
    Try
        Dim userInput As String = TextBox_UserInput.Text
        Dim systemPrompt As String = TextBox_SystemPrompt.Text
        Dim maxTokens As Integer = CInt(TextBox_MaxTokens.Text)
        Dim temperature As Double = CDbl(TextBox_Temperature.Text)
        Dim topP As Double = CDbl(TextBox_TopP.Text)
        Dim modelName As String = ComboBox_LLMModels.SelectedItem.ToString()
        Dim imageData As Byte() = Nothing
        Dim endpoint As String = TextBox_Endpoint.Text
        Dim apiKey As String = TextBox_APIKey.Text
        Dim streamResponse As Boolean = CheckBox_Stream.Checked

        If CheckBox_AppendAIResponses.Checked = True Then
            TextBox_AIResponse.AppendText(""USER: "" & vbCrLf & userInput & vbCrLf & vbCrLf & ""AI: "" & vbCrLf)
        Else
            TextBox_AIResponse.Text = """"
        End If

        Await AskAI(userInput, systemPrompt, maxTokens, temperature, topP, modelName, imageData, endpoint, apiKey, streamResponse, AddressOf CallBackFunction)
    Catch ex As Exception
        MessageBox.Show(""Error getting LLM response:"" & vbCrLf & vbCrLf & ex.Message)
    End Try
End Sub


Public Sub CallBackFunction(text As String)
    If TextBox_AIResponse.InvokeRequired Then
        TextBox_AIResponse.Invoke(New Action(Of String)(AddressOf CallBackFunction), text)
    Else
        TextBox_AIResponse.AppendText(text)
        TextBox_AIResponse.SelectionStart = TextBox_AIResponse.TextLength
        TextBox_AIResponse.ScrollToCaret()
    End If
End Sub


Private Sub Button_Abort_Click(sender As Object, e As EventArgs) Handles Button_Abort.Click
    AbortAIRequest()
End Sub
"





    Private Sub FormAbout_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub



    Private Sub Button_About_CodeExampleMinimum_Click(sender As Object, e As EventArgs) Handles Button_About_CodeExampleMinimum.Click
        TextBox_CodeExamples.Text = codeExample_BareMinimum
    End Sub

    Private Sub Button_About_CodeExamplesBasic_Click(sender As Object, e As EventArgs) Handles Button_About_CodeExamplesBasic.Click
        TextBox_CodeExamples.Text = codeExample_Basic
    End Sub

    Private Sub Button_About_CodeExampleFull_Click(sender As Object, e As EventArgs) Handles Button_About_CodeExampleFull.Click
        TextBox_CodeExamples.Text = codeExample_AllParameters
    End Sub



    Private Sub Button_About_Close_Click(sender As Object, e As EventArgs) Handles Button_About_Close.Click
        Me.Close()
    End Sub

    Private Sub FormAbout_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        Me.Size = New Size(735, 850)
        Me.Location = New Point((Screen.PrimaryScreen.Bounds.Width - Me.Width) / 2, (Screen.PrimaryScreen.Bounds.Height - Me.Height) / 2)
    End Sub



End Class