﻿

' AUTHOR: CoffeeCodeConverter
' CREATION DATE: 05/02/2025

' REQUIREMENTS:
' .NET Framework 4.5.1 or higher
' Newtonsoft.JSON NuGet Package
'
' 
' DESCRIPTION:
' A comprehensive module for easily interacting with LLM's either locally (ollama / lm studio) or online (OpenAI)
' NOTE: Global variable defaults to using LM Studio as the preferred method, but you can change "defaultAIEndpoint" value to anything
'
' Provides a single, highly configurable function, that allows streaming on/off,
' automatically detects to use ollama or lm studio/openaI formatting based on the URL, 
' and allows you to set temperature, TopP, MaxTokens, model, endpoint, imageData per function call, so you can mix it between multiple LLMs too. 

' NOTE:
' the main function defaults to streaming the response, which is asynchronous - so you need to create YOUR OWN callBack function to update some textbox or UI control
' from the captured responses.  


' MAIN FUNCTION:
' Await AskAI()

' BARE MINIMUM EXAMPLE 
' Await AskAI(userInput, callBackFunc:=AddressOf MyCallBackFunction)

' USING ALL PARAMETERS EXAMPLE 
' Await AskAI(userInput, systemPrompt, maxTokens, temperature, topP, modelName, imageData, endpoint, apiKey, streamResponse, AddressOf MyCallBackFunction)


' EXAMPLE CALLBACK FUNCTION 
'Public Sub MyCallBackFunction(text As String)
'    If TextBox_AIResponse.InvokeRequired Then
'        TextBox_AIResponse.Invoke(New Action(Of String)(AddressOf MyCallBackFunction), text)
'    Else
'        TextBox_AIResponse.AppendText(text)
'        TextBox_AIResponse.SelectionStart = TextBox_AIResponse.TextLength
'        TextBox_AIResponse.ScrollToCaret()
'    End If
'End Sub


' HELPER FUNCTION TO ABORT A STREAM IN PROGRESS:
' AbortAIRequest()






Imports System.Threading
Imports System.Net.Http
Imports System.Net.Http.Headers
Imports Newtonsoft.Json                 ' Add Newtonsoft.JSON NuGet Package
Imports Newtonsoft.Json.Linq            ' Add Newtonsoft.JSON NuGet Package
Imports System.Text
Imports System.IO



Module FunctionsLLM


    ' GLOBAL VARIBALES
    ' ==============================================================================
    Public moduleVersionLLMs As String = "1.0.0.20"
    Public defaultAIEndpoint As String = "http://127.0.0.1:1234/v1/chat/completions"    ' Default for LM Studio running a Local LLM - API Calls default to this, but you can also override the endpoint as an argument to the API call for flexibility. 
    Public defaultAIAPIKey As String = "your_openai_api_key"                            ' LM Studio / Ollama will ignore the API Key when running Local LLM So litterally anything will work - OpenAI requires a real API Key though - you can override the API Key as an argument to the API Call for flexibility. 
    Const globalDefaultModel As String = "gpt-3.5-turbo"                                ' LM Studio ignores the model, as it uses whatevers been loaded in LM Studios server. Ollama though, requires a model Name. 
    Const globalDefaultTopP As Double = 1.0
    Const globalDefaultMaxTokens As Integer = 1024
    Const globalDefaultTemperature As Double = 0.7
    Dim cts As CancellationTokenSource

    Public AIOperationInProgress As Boolean = False
    Public asyncOperationInProgress As Boolean = False




    Public Function GenerateToken() As CancellationTokenSource
        cts = New CancellationTokenSource()
        Return cts
    End Function


    Public Sub AbortAIRequest()
        Try
            If cts IsNot Nothing Then
                cts.Cancel()
                cts.Dispose()
            End If
        Catch ex As Exception
            MessageBox.Show("Error trying to cancel token" & vbCrLf & ex.Message)
        End Try
    End Sub





    ' HELPER FUNCTION - SO YOU ONLY NEED A SINGLE FUNCTION TO SATISFY BOTH STREAMING & NON-STREAMING
    Public Async Function AskAI(ByVal userInput As String,
                            Optional ByVal prePrompt As String = "",
                            Optional ByVal maxTokens As Integer = globalDefaultMaxTokens,
                            Optional ByVal temperature As Double = globalDefaultTemperature,
                            Optional ByVal topP As Double = globalDefaultTopP,
                            Optional ByVal model As String = globalDefaultModel,
                            Optional ByVal imageData As Byte() = Nothing,
                            Optional ByVal overrideAPIEndpoint As String = "",
                            Optional ByVal overrideAPIKey As String = "",
                            Optional ByVal streamResponse As Boolean = True,
                            Optional callBackFunc As Action(Of String) = Nothing) As Task(Of String)

        If streamResponse = False Then
            ' Handle the full response case
            Dim tempString = Await AskAIFull(userInput, prePrompt, maxTokens, temperature, topP, model, imageData, overrideAPIEndpoint, overrideAPIKey)

            ' Ollama specifically needs additional clean up for this part, whereas lmstudio / OpenAI do not 
            If overrideAPIEndpoint.ToLower.Contains("/api/chat") Or overrideAPIEndpoint.ToLower.Contains("/api/generate") Then
                tempString = ExtractContentFromOllamaChunk(tempString)
            End If

            If callBackFunc IsNot Nothing Then
                callBackFunc(tempString)
            End If

            Return tempString
        Else
            Try
                Dim tempStringBuilder As New StringBuilder
                Using reader As New StreamReader(Await AskAIStream(userInput, prePrompt, maxTokens, temperature, topP, model, imageData, overrideAPIEndpoint, overrideAPIKey))
                    While Not reader.EndOfStream
                        If cts.Token.IsCancellationRequested Then
                            MessageBox.Show("Cancelled Stream from LLM")
                            Return "Cancelled Stream from LLM"
                        End If

                        Dim JSONLine As String = Await reader.ReadLineAsync()

                        If overrideAPIEndpoint.ToLower.Contains("/api/chat") Or overrideAPIEndpoint.ToLower.Contains("/api/generate") Then
                            tempStringBuilder.Append(ExtractContentFromOllamaChunk(JSONLine) & " ")
                        Else
                            tempStringBuilder.Append(ExtractContentFromChunk(JSONLine) & vbCrLf)
                        End If

                        If callBackFunc IsNot Nothing Then
                            If overrideAPIEndpoint.ToLower.Contains("/api/chat") Or overrideAPIEndpoint.ToLower.Contains("/api/generate") Then
                                callBackFunc(
                                    (ExtractContentFromOllamaChunk(JSONLine)))
                            Else
                                callBackFunc(
                                    (ExtractContentFromChunk(JSONLine)))
                            End If
                        End If

                        Application.DoEvents()
                    End While

                    callBackFunc(
                                 (vbCrLf & vbCrLf))
                End Using


                Return tempStringBuilder.ToString & "Complete - End of Stream"

            Catch ex As Exception

                If ex.Message.ToLower.Contains("the cancellationtokensource has been disposed") Then
                    Dim tempExString As String = "Cancelled Stream from LLM"
                    MessageBox.Show(tempExString, "Cancelled Stream", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Return tempExString

                ElseIf ex.Message.ToLower.Contains("value cannot be null. (parameter 'stream')") Then
                    Dim tempExString As String = ""
                    If userInput = "" Then
                        tempExString = "Error Streaming from LLM" & vbCrLf & "Please enter some text, or a question, or anything you can think of really!" & vbCrLf & vbCrLf & "Value cannot be Null: userInput"
                    Else
                        tempExString = "Error Streaming from LLM" & vbCrLf & "Ensure the LLM is running, and check your connectivity to it." & vbCrLf & vbCrLf & ex.Message
                    End If
                    MessageBox.Show(tempExString, "Error Streaming from LLM", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return tempExString

                Else
                    MessageBox.Show("Error Streaming from LLM:" & vbCrLf & vbCrLf & ex.Message, "Error Streaming From LLM", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return "Error Streaming from LLM:" & vbCrLf & vbCrLf & ex.Message
                End If
            End Try
        End If

    End Function






    ' CALL TO LLM - ENTIRE RESPONSE
    Public Async Function AskAIFull(ByVal userInput As String,
                            Optional ByVal prePrompt As String = "",
                            Optional ByVal maxTokens As Integer = globalDefaultMaxTokens,
                            Optional ByVal temperature As Double = globalDefaultTemperature,
                            Optional ByVal topP As Double = globalDefaultTopP,
                            Optional ByVal model As String = globalDefaultModel,
                            Optional ByVal imageData As Byte() = Nothing,
                            Optional ByVal overrideAPIEndpoint As String = "",
                            Optional ByVal overrideAPIKey As String = "") As Task(Of String)

        cts = GenerateToken()
        Dim tempResponse As String = ""

        Using client As New HttpClient()
            ' Check for an Overridden API Key
            Dim tempAPIKey As String = defaultAIAPIKey
            If Not overrideAPIKey = "" Then
                tempAPIKey = overrideAPIKey
            End If

            ' Check for an Overridden Endpoint URL
            Dim tempEndpoint As String = defaultAIEndpoint
            If Not overrideAPIEndpoint = "" Then
                tempEndpoint = overrideAPIEndpoint
            End If

            client.DefaultRequestHeaders.Authorization = New AuthenticationHeaderValue("Bearer", tempAPIKey)
            Dim requestBody As String = GenerateRequestBody(userInput, prePrompt, maxTokens, temperature, topP, model, imageData, overrideAPIEndpoint)
            Dim content As StringContent = New StringContent(requestBody, Encoding.UTF8, "application/json")

            Try
                AIOperationInProgress = True

                ' Send Request to the AI Model
                Dim response As HttpResponseMessage = Await client.PostAsync(tempEndpoint, content, cts.Token)
                Dim responseString As String = Await response.Content.ReadAsStringAsync()

                ' Check the AI Response 
                If response.IsSuccessStatusCode Then
                    Dim responseObject As JObject = JsonConvert.DeserializeObject(Of JObject)(responseString)
                    If overrideAPIEndpoint.ToLower.Contains("/api/chat") Or overrideAPIEndpoint.ToLower.Contains("/api/generate") Then
                        ' FOR OLLAMA
                        tempResponse = responseObject.ToString()

                    Else
                        'For OPENAI / LMSTUDIO
                        If responseObject.ContainsKey("choices") Then
                            Dim choices As JArray = DirectCast(responseObject("choices"), JArray)
                            Dim messageContent As String = choices(0)("message")("content").ToString()
                            tempResponse = messageContent
                        Else
                            tempResponse = "ERROR: 'choices' key not found in the AI response."
                        End If

                    End If
                Else
                    tempResponse = $"ERROR: API request failed with status code {response.StatusCode}. Response: {responseString}"
                End If

            Catch ex As TaskCanceledException
                tempResponse = "Operation Aborted! "

            Catch ex As Exception
                tempResponse = "ERROR: " & ex.Message & vbCrLf & vbCrLf & ex.StackTrace

            Finally
                AIOperationInProgress = False
            End Try

        End Using

        Return tempResponse

    End Function





    ' CALL TO LLM - STREAMED
    '' V2
    Public Async Function AskAIStream(ByVal userInput As String,
                            Optional ByVal prePrompt As String = "",
                            Optional ByVal maxTokens As Integer = globalDefaultMaxTokens,
                            Optional ByVal temperature As Double = globalDefaultTemperature,
                            Optional ByVal topP As Double = globalDefaultTopP,
                            Optional ByVal model As String = globalDefaultModel,
                            Optional ByVal imageData As Byte() = Nothing,
                            Optional ByVal overrideAPIEndpoint As String = "",
                            Optional ByVal overrideAPIKey As String = "") As Task(Of Stream)

        cts = GenerateToken()

        Using client As New HttpClient()

            ' Check for an Overridden API Key
            Dim tempAPIKey As String = defaultAIAPIKey
            If Not overrideAPIKey = "" Then
                tempAPIKey = overrideAPIKey
            End If

            ' Check for an Overridden Endpoint URL
            Dim tempEndpoint As String = defaultAIEndpoint
            If Not overrideAPIEndpoint = "" Then
                tempEndpoint = overrideAPIEndpoint
            End If

            client.DefaultRequestHeaders.Authorization = New AuthenticationHeaderValue("Bearer", tempAPIKey)
            Dim requestBody As String = GenerateRequestBody(userInput, prePrompt, maxTokens, temperature, topP, model, imageData, overrideAPIEndpoint, True)
            Dim content As StringContent = New StringContent(requestBody, Encoding.UTF8, "application/json")

            Try
                AIOperationInProgress = True

                Dim request As New HttpRequestMessage(HttpMethod.Post, tempEndpoint) With {
                    .Content = content
                }

                request.Headers.Authorization = New AuthenticationHeaderValue("Bearer", tempAPIKey)
                Dim response As HttpResponseMessage = Await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, cts.Token)
                If response.IsSuccessStatusCode Then
                    Return Await response.Content.ReadAsStreamAsync()
                Else
                    ' Handle API request failure
                    Dim responseString As String = Await response.Content.ReadAsStringAsync()
                    Throw New Exception($"ERROR: API request failed with status code {response.StatusCode}. Response: {responseString}")
                End If

            Catch ex As TaskCanceledException
                Return Nothing

            Catch ex As Exception
                Return Nothing

            Finally
                AIOperationInProgress = False
            End Try

        End Using
    End Function





    Public Function GenerateRequestBody(ByVal userInput As String,
                                    Optional ByVal prePrompt As String = "",
                                    Optional ByVal maxTokens As Integer = globalDefaultMaxTokens,
                                    Optional ByVal temperature As Double = globalDefaultTemperature,
                                    Optional ByVal topP As Double = globalDefaultTopP,
                                    Optional ByVal model As String = globalDefaultModel,
                                    Optional ByVal imageData As Byte() = Nothing,
                                    Optional ByVal overrideAPIEndpoint As String = "",
                                    Optional enableStreaming As Boolean = False) As String

        Dim requestBody As New JObject()
        Dim messageArray As New JArray()

        ' Determine the API format based on the endpoint
        Select Case True
            Case overrideAPIEndpoint.ToLower.Contains("/api/chat") Or overrideAPIEndpoint.ToLower.Contains("/api/generate")
                ' Ollama
                requestBody = GenerateOllamaMessage(userInput, prePrompt, model, temperature, enableStreaming)

            Case Else
                ' OpenAI / LM Studio 
                messageArray = GenerateOpenAIMessage(userInput, prePrompt, imageData)
                requestBody = New JObject() From {
                {"model", model},
                {"messages", messageArray},
                {"max_tokens", maxTokens},
                {"temperature", temperature},
                {"top_p", topP},
                {"stream", enableStreaming}
            }
        End Select

        Return requestBody.ToString()
    End Function




    ' Function to generate OpenAI and LMStudio messages
    Private Function GenerateOpenAIMessage(ByVal userInput As String, ByVal prePrompt As String, ByVal imageData As Byte()) As JArray
        Dim messageArray As New JArray()

        If Not String.IsNullOrEmpty(prePrompt) Then
            messageArray.Add(New JObject() From {
            {"role", "system"},
            {"content", prePrompt}
        })
        End If

        Dim userMessage As New JObject()
        userMessage.Add("role", "user")

        Dim contentArray As New JArray()
        Dim textObject As New JObject()
        textObject.Add("type", "text")
        textObject.Add("text", userInput)
        contentArray.Add(textObject)

        If imageData IsNot Nothing Then
            Dim imageBase64 As String = Convert.ToBase64String(imageData)
            Dim imageObject As New JObject()
            imageObject.Add("type", "image_url")
            imageObject.Add("image_url", New JObject From {
            {"url", $"data:image/jpeg;base64,{imageBase64}"}
        })
            contentArray.Add(imageObject)
        End If

        userMessage.Add("content", contentArray)
        messageArray.Add(userMessage)

        Return messageArray
    End Function




    Private Function GenerateOllamaMessage(ByVal userInput As String,
                                           ByVal prePrompt As String,
                                           llmModel As String,
                                           ByVal temp As Double,
                                           ByVal enableStreaming As Boolean) As JObject

        Dim requestBody As New JObject()

        requestBody.Add("model", llmModel)

        If Not String.IsNullOrEmpty(prePrompt) Then
            requestBody.Add("prompt", prePrompt & " " & userInput)
        Else
            requestBody.Add("prompt", userInput)
        End If

        ' Add options
        Dim options As New JObject()
        options.Add("temperature", temp)
        requestBody.Add("options", options)
        requestBody.Add("stream", enableStreaming)

        Return requestBody
    End Function





    Public Function ExtractContentFromChunk(chunk As String) As String

        Dim content As String = ""
        If chunk.Trim().StartsWith("data: {") Then
            Try
                Dim json As JObject = JObject.Parse(chunk.Replace("data:", ""))
                Dim choices As JArray = json.SelectToken("choices")
                If choices IsNot Nothing AndAlso choices.Count > 0 Then
                    For Each choice As JObject In choices
                        Dim delta As JObject = choice.SelectToken("delta")
                        If delta IsNot Nothing Then
                            Dim contentValue As JToken = delta.SelectToken("content")
                            If contentValue IsNot Nothing Then
                                content &= contentValue.ToString()
                            End If
                        End If
                    Next
                End If

            Catch ex As Exception
                MessageBox.Show($"Error extracting content from chunk: {ex.Message}" & vbCrLf & vbCrLf & ex.StackTrace)
            End Try
        End If

        Return content
    End Function





    Public Function ExtractContentFromOllamaChunk(chunk As String) As String
        Dim content As String = ""
        If chunk.Trim().StartsWith("{") AndAlso chunk.Trim().EndsWith("}") Then
            Try
                Dim json As JObject = JObject.Parse(chunk)
                Dim response As JToken = json.SelectToken("response")
                If response IsNot Nothing Then
                    content &= response.ToString()
                End If
            Catch ex As Exception
                MessageBox.Show($"Error extracting content from Ollama chunk: {ex.Message}" & vbCrLf & vbCrLf & ex.StackTrace)
            End Try
        End If

        Return content
    End Function





End Module
